---
title: Child of Test
parent: Test
has_children: true
nav_order: 1
---

# Child of test

I am a child page.
